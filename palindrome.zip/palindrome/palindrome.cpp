#include "palindrome.h"
#include <ctime>
#include <cstdio>
#include <cmath>

// ITERATIVE APPROACH
bool isPalindromeIterative(string s) {
    int left = 0;
    int right = s.length() - 1;

    while (left < right) {
        if (s[left] != s[right]) {
            return false;
        }
        left++;
        right--;
    }
    return true;
}

// RECURSIVE APPROACH
bool isPalindromeRecursive(string s, int left, int right) {
    // Base case: pointers have met or crossed
    if (left >= right) {
        return true;
    }

    // Check current characters
    if (s[left] != s[right]) {
        return false;
    }

    // Recursive call with updated pointers
    return isPalindromeRecursive(s, left + 1, right - 1);
}

// Measure execution time - FIXED VERSION
double measureTime(string s, bool useRecursive) {
    int loops = 50000; // Run many times for accurate measurement

    clock_t start = clock();

    for (int i = 0; i < loops; i++) {
        if (useRecursive) {
            isPalindromeRecursive(s, 0, s.length() - 1);
        } else {
            isPalindromeIterative(s);
        }
    }

    clock_t end = clock();

    // FIXED: Calculate average time in nanoseconds properly
    double elapsedSeconds = (double)(end - start) / CLOCKS_PER_SEC;
    double totalTimeNs = elapsedSeconds * 1000000000.0; // Convert to nanoseconds
    double avgTimeNs = totalTimeNs / loops;

    // Round to 1 decimal place for cleaner output
    avgTimeNs = round(avgTimeNs * 10.0) / 10.0;

    // Avoid zero values
    if (avgTimeNs < 0.1) {
        avgTimeNs = 0.1;
    }

    return avgTimeNs;
}

// Save results to CSV file
void saveToCSV(string filename, string data) {
    FILE* file = fopen(filename.c_str(), "w");
    if (file != NULL) {
        fprintf(file, "%s", data.c_str());
        fclose(file);
    }
}
