#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include "palindrome.h"
using namespace std;

int main() {
    int numTests;

    cout << "=== PALINDROME CHECKER ===" << endl;
    cout << "\nEnter how many strings to test: ";
    cin >> numTests;
    cin.ignore();

    // CSV header
    string csvData = "No;String;Length;Palindrome;Iterative_ns;Recursive_ns;Ratio\n";

    for (int i = 1; i <= numTests; i++) {
        string input;
        cout << "\nEnter string " << i << ": ";
        getline(cin, input);

        // Measure execution time
        double iterTime = measureTime(input, false);
        double recurTime = measureTime(input, true);

        // Check if palindrome
        bool isPalin = isPalindromeIterative(input);

        // Calculate ratio
        double ratio = 0.0;
        if (iterTime > 0) {
            ratio = recurTime / iterTime;
        }

        // Display results
        cout << "\n--- Results for: \"" << input << "\" ---" << endl;
        cout << "Length: " << input.length() << " characters" << endl;
        cout << "Result: " << (isPalin ? "PALINDROME" : "NOT A PALINDROME") << endl;

        cout << "\nIterative: " << fixed << setprecision(1) << iterTime << " ns" << endl;
        cout << "Recursive: " << fixed << setprecision(1) << recurTime << " ns" << endl;

        cout << "\nComparison:" << endl;
        cout << "  Ratio (Recursive/Iterative): " << fixed << setprecision(2) << ratio << "x" << endl;

        if (iterTime < recurTime) {
            cout << "  -> Iterative is FASTER" << endl;
        } else if (recurTime < iterTime) {
            cout << "  -> Recursive is FASTER" << endl;
        } else {
            cout << "  -> Similar speed" << endl;
        }
        cout << "----------------------------------------" << endl;

        // FIXED: Add to CSV with proper formatting
        stringstream ss;
        ss << i << ";"
           << input << ";"
           << input.length() << ";"
           << (isPalin ? "Yes" : "No") << ";"
           << fixed << setprecision(1) << iterTime << ";"
           << fixed << setprecision(1) << recurTime << ";"
           << fixed << setprecision(2) << ratio << "\n";

        csvData += ss.str();
    }

    // Save to file
    saveToCSV("results.csv", csvData);

    cout << "\n=== COMPLETE ===" << endl;
    cout << "Results saved to: results.csv" << endl;
    cout << "Open the CSV file in Excel to create graphs!" << endl;

    return 0;
}
