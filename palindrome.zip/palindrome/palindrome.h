#ifndef PALINDROME_H_INCLUDED
#define PALINDROME_H_INCLUDED

#include <string>
using namespace std;

bool isPalindromeIterative(string s);
bool isPalindromeRecursive(string s, int left, int right);
double measureTime(string s, bool useRecursive);
void saveToCSV(string filename, string data);

#endif // PALINDROME_H_INCLUDED
